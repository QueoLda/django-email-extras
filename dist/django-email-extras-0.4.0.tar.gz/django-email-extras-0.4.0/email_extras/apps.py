from django.apps import AppConfig


class EmailExtrasConfig(AppConfig):
    name = 'email_extras'
    verbose_name = 'Email Extras'
