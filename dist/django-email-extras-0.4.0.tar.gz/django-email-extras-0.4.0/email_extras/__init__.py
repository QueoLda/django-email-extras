__version__ = "0.4.0"
default_app_config = "email_extras.apps.EmailExtrasConfig"
